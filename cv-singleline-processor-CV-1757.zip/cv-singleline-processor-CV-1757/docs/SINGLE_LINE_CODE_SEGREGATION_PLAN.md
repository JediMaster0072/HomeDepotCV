# Single-Line Code Segregation Plan
This document summarizes the behavior-preserving split of the single-line processor into smaller, easier-to-review modules. The goal is to keep the pipeline behavior the same while making each stage easier to understand, validate, and share with another team.

## New End-To-End Flow
```mermaid
graph TD
    A[Pub/Sub message] --> B[app.py process]
    B --> C[services/image_processor.py download_image]
    C --> D[app.py process_image_new]
    D --> E[new_inference_pipeline_full_image.py run_image]

    E --> F[pipeline/detection_tracks.py detection + ClipTrack setup]
    F --> G[pipeline/detection_stage.py crop + preprocess]
    G --> H[pipeline/strips.py build strip layout]
    H --> I[pipeline/segmentation_stage.py segment strips]
    I --> J[pipeline/masked_original_builder.py masked original OCR image]
    J --> K[pipeline/ocr_stage.py Google OCR]
    K --> L[utils/google_ocr_utils.py parse SKUs]
    L --> M[pipeline/assignment.py assign OCR to detections]
    M --> N[output/sku_payload.py build output JSON]
    N --> O[app.py publish_message]

    D --> P{No SKUs or model failure?}
    P -- Yes --> Q[legacy/ocr_parsing.py legacy OCR parsing]
    Q --> R[app.py legacy output path]
    R --> O
```

## Current Status
The first major segregation pass is complete and tests are passing.

- `app.py` still owns Pub/Sub startup, message processing, fallback routing, metrics, and publish.
- `new_inference_pipeline_full_image.py` still owns the top-level `HomeDepotInferencePipeline.run_image()` orchestration.
- Reusable stage logic has been moved into smaller modules.
- Existing public imports and wrapper methods are preserved for compatibility.
- Local tests pass: `19 passed, 1 warning`.

## New Module Structure
```mermaid
graph TD
    A[Original large files] --> B[app.py]
    A --> C[new_inference_pipeline_full_image.py]

    B --> D[output/sku_payload.py]
    B --> E[legacy/ocr_parsing.py]

    C --> F[pipeline/detection_tracks.py]
    C --> G[pipeline/detection_stage.py]
    C --> H[pipeline/strips.py]
    C --> I[pipeline/segmentation_stage.py]
    C --> J[pipeline/masked_original_builder.py]
    C --> K[pipeline/ocr_stage.py]
    C --> L[pipeline/assignment.py]
    C --> M[utils/validation_visualizer.py]
```

### Implemented Modules
- `output/sku_payload.py`: `SkuData`, output JSON encoding, SKU normalization, bbox string formatting, and new-pipeline result JSON.
- `legacy/ocr_parsing.py`: legacy fallback SKU extraction and OCR bbox matching helpers.
- `pipeline/detection_tracks.py`: detection endpoint fallback handling, buffered crop extraction, `ClipTrack` initialization, and clip-item packaging.
- `pipeline/detection_stage.py`: crop extraction, deblur, denoise, and crop preprocessing helpers.
- `pipeline/strips.py`: crop grouping, center padding, and strip coordinate layout.
- `pipeline/segmentation_stage.py`: strip segmentation prediction, binary mask normalization, mask expansion, per-crop segmentation checks, and masked strip clips.
- `pipeline/masked_original_builder.py`: full-resolution masked-original image reconstruction for the single OCR call.
- `pipeline/ocr_stage.py`: Google OCR call and handoff to SKU parsing.
- `pipeline/assignment.py`: OCR word-to-detection assignment and bbox helper functions.
- `utils/validation_visualizer.py`: contact-sheet generator wired behind `CV_SINGLELINE_DEBUG_VALIDATION`.

## Old-To-New Mapping
```mermaid
graph LR
    A[app.py output helpers] --> B[output/sku_payload.py]
    C[app.py legacy OCR helpers] --> D[legacy/ocr_parsing.py]
    E[new_inference_pipeline_full_image.py detection + track setup] --> F[pipeline/detection_tracks.py]
    G[new_inference_pipeline_full_image.py crop helpers] --> H[pipeline/detection_stage.py]
    I[new_inference_pipeline_full_image.py strip helpers] --> J[pipeline/strips.py]
    K[new_inference_pipeline_full_image.py segmentation helpers] --> L[pipeline/segmentation_stage.py]
    M[new_inference_pipeline_full_image.py masked original builder] --> N[pipeline/masked_original_builder.py]
    O[new_inference_pipeline_full_image.py OCR helpers] --> P[pipeline/ocr_stage.py]
    Q[new_inference_pipeline_full_image.py assignment helpers] --> R[pipeline/assignment.py]
    S[No standalone validation utility] --> T[utils/validation_visualizer.py]
```

Compatibility note: `app.py` still imports extracted output and legacy helpers, and `HomeDepotInferencePipeline` keeps wrapper methods for extracted detection/crop, strip, segmentation, OCR, and assignment helpers. This keeps existing tests and imports working while the implementation lives in smaller files.

## What Was Extracted
### From `app.py`
- `SkuData` -> `output/sku_payload.py::SkuData`
- `encoder_sku_data()` -> `output/sku_payload.py::encoder_sku_data()`
- `prepare_sku_result_json_new()` -> `output/sku_payload.py::prepare_sku_result_json_new()`
- `normalize_sku_text()` -> `output/sku_payload.py::normalize_sku_text()`
- `bbox_to_legacy_string()` -> `output/sku_payload.py::bbox_to_legacy_string()`
- `find_sku_entities()` -> `legacy/ocr_parsing.py::find_sku_entities()`
- `detect_bounding_box()` -> `legacy/ocr_parsing.py::detect_bounding_box()`
- `find_bounding_values()` -> `legacy/ocr_parsing.py::find_bounding_values()`
- `structure_bounding()` -> `legacy/ocr_parsing.py::structure_bounding()`

### From `new_inference_pipeline_full_image.py`
- Detection endpoint fallback handling, `ClipTrack` initialization, and clip item packaging -> `pipeline/detection_tracks.py`
- `crop()`, `_preprocess()`, `_deblur()`, `_denoise()` -> `pipeline/detection_stage.py`
- `group_clip_items()`, `center_pad()`, `create_strip()` -> `pipeline/strips.py`
- `_mask_single_strip()`, `_predict_binary_strip_mask()`, `process_binary_mask_with_rotation()`, `_apply_mask_to_strip_preserve_unsegmented_clips()`, `_clip_has_segmentation()`, `_apply_mask_to_strip()` -> `pipeline/segmentation_stage.py`
- `_build_masked_original_image()` implementation -> `pipeline/masked_original_builder.py`
- `_run_google_ocr_words()`, `_call_google_ocr_np()` -> `pipeline/ocr_stage.py`
- `_assign_word_to_track_in_original()`, `_bbox_center()`, `_point_in_bbox()` -> `pipeline/assignment.py`

## Validation Contact Sheet Plan
```mermaid
graph TD
    A[One input image] --> B[Original image with OD boxes]
    A --> C[Buffered crop tiles]
    C --> D[Strip layout]
    D --> E[Segmentation mask + masked strip]
    E --> F[Masked original image sent to OCR]
    F --> G[Final OCR boxes + assigned detections]
    G --> H[Single validation contact sheet]
```

`utils/validation_visualizer.py` is wired behind `CV_SINGLELINE_DEBUG_VALIDATION`. It is off by default; when enabled, it writes a contact sheet to `debug_outputs/` showing detections, buffered crops, segmentation clips, masked OCR input, and final OCR boxes.

## Still Pending
```mermaid
graph TD
    A[Remaining work] --> B[Runtime validation after VPN/Vertex access]
    A --> C[Optional deeper stage tests with real endpoint fixtures]
```

- Masked-original reconstruction now lives in `pipeline/masked_original_builder.py`.
- Detection fallback handling and `ClipTrack` initialization now live in `pipeline/detection_tracks.py`.
- Validation contact sheets are wired behind `CV_SINGLELINE_DEBUG_VALIDATION`.
- Stage-level tests were added in `test/test_pipeline_stages.py`.
- Full runtime validation still requires VPN/private Vertex endpoint access.

## Suggested Update To Vaibhav
I completed the first go-through of the single-line codebase and continued the behavior-preserving segregation. The service path is clear: `app.py` owns Pub/Sub/message orchestration and fallback handling, while `new_inference_pipeline_full_image.py` now mostly orchestrates stage modules. I extracted output payload building, legacy OCR parsing/bounding helpers, detection fallback and `ClipTrack` setup, crop/preprocessing helpers, strip layout, segmentation, masked-original reconstruction, Google OCR client helpers, OCR assignment helpers, and a validation contact-sheet utility behind `CV_SINGLELINE_DEBUG_VALIDATION`. Existing public imports and pipeline wrapper methods are preserved, and the local test suite passes (`19 passed`). The main blocker for full runtime validation remains VPN/private Vertex endpoint access.
