# Documentation Index

Use these docs when reviewing or onboarding to the single-line processor:

- `SINGLE_LINE_CODE_SEGREGATION_PLAN.md`: current refactor/segregation status, new module flow, remaining work, and Vaibhav-ready update.
- `SINGLE_LINE_PIPELINE_GUIDE.md`: prose walkthrough of one image moving through the single-line pipeline.
- `PIPELINE_METHOD_ORDER_LINKS.md`: ordered method-level reading map for the production path, updated for the new stage modules.
