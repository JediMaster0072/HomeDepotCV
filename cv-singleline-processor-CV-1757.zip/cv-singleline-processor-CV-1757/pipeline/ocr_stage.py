import numpy as np
from google.cloud import vision

from services.image_processor import numpy_image_to_base64_png
from utils.google_ocr_utils import parse_google_ocr_words


# Pipeline order: 29
# Description: Runs Google OCR on the masked original image and returns parsed SKU candidates.
def run_google_ocr_words(gcv_client: vision.ImageAnnotatorClient, image: np.ndarray) -> list[dict]:
    """
    Run Google Vision OCR on an in-memory NumPy image and return validated SKU results.

    Returns:
    [
        {
            "text": "1004334515",
            "raw_text": "1004 334-515",
            "bbox": BoundingBox(...),
            "confidence": 1.0,
            "source": "google_ocr_sku_parse",
        },
        ...
    ]
    """
    annotations = call_google_ocr_np(gcv_client, image)

    if not annotations:
        return []

    return parse_google_ocr_words(annotations)


# Pipeline order: 30
# Description: Encodes a NumPy image and calls Google Vision document text detection.
def call_google_ocr_np(gcv_client: vision.ImageAnnotatorClient, image: np.ndarray) -> list[dict] | None:
    """
    Calls Google Vision OCR using an in-memory OpenCV / NumPy image.

    image: np.ndarray in OpenCV BGR format
    """
    if image is None or image.size == 0:
        return None

    _, png_image_bytes = numpy_image_to_base64_png(image, return_bytes=True)

    gcv_image = vision.Image(content=png_image_bytes)

    response = gcv_client.document_text_detection(
        image=gcv_image,
        image_context=vision.ImageContext(language_hints=["en-t-i0"]),
    )

    if response.error.message:
        raise RuntimeError(f"Google Vision OCR error: {response.error.message}")

    return list(response.text_annotations)
